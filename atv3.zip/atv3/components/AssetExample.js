import {
  StyleSheet,
  View,
  Image,
  TouchableOpacity,
  Text,
  SafeAreaView,
} from 'react-native';
//import{SafeAreaView} from 'react-native-safe-area-view';

function galeriaFotos() {
  return (
    <SafeAreaView style={estilo.container}>
      <View style={estilo.botao}>
        <TouchableOpacity style={estilo.button}>
          <Text style={estilo.texto}>selecionar</Text>
        </TouchableOpacity>

        <TouchableOpacity style={estilo.button}>
          <Text style={estilo.texto}>editar</Text>
        </TouchableOpacity>

        <TouchableOpacity style={estilo.button}>
          <Text style={estilo.texto}>excluir</Text>
        </TouchableOpacity>
      </View>
      <View style={estilo.botao}>
        <TouchableOpacity style={estilo.button2}>
          <Text>TEMA</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
    
  );
}

const estilo = StyleSheet.create({
  container: {
    alignItems: 'center',
    padding: 10,
  },

  botao: {
    flexDirection: 'row',
    gap: 10,
    marginTop:10,
  },
  
  button:{
    backgroundColor:'#3f6e55',
    borderRadius:10,
    padding:5,
    width:100,
    height:25,
    alignItems:'center'
  },

  button2:{
    backgroundColor:'#3f6e55',
    borderRadius:10,
    padding:5,
    width:100,
    height:25,
    alignItems:'center'
  },

  texto:{
    color:'#fff'
  }


});

export default galeriaFotos;
