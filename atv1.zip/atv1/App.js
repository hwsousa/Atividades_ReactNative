import {
  StyleSheet,
  View,
  Image,
  TouchableOpacity,
  Text,
  SafeAreaView,
} from 'react-native';
//import{SafeAreaView} from 'react-native-safe-area-view';

function galeriaFotos() {
  return (
    <SafeAreaView style={estilo.container}>
      <View>
        <Image style={estilo.foto} source={require('./assets/eu1.jpeg')} />
      </View>
      <View style={estilo.botao}>
        <TouchableOpacity style={estilo.button}>
          <Text style={estilo.texto}>Curtir</Text>
        </TouchableOpacity>

        <TouchableOpacity style={estilo.button}>
          <Text style={estilo.texto}>Comentar</Text>
        </TouchableOpacity>

        <TouchableOpacity style={estilo.button}>
          <Text style={estilo.texto}>Compartilhar</Text>
        </TouchableOpacity>
      </View>
      <View>
        <Image style={estilo.foto} source={require('./assets/eu2.jpeg')} />
      </View>
      <View style={estilo.botao}>
        <TouchableOpacity style={estilo.button}>
          <Text style={estilo.texto}>Curtir</Text>
        </TouchableOpacity>

        <TouchableOpacity style={estilo.button}>
          <Text style={estilo.texto}>Comentar</Text>
        </TouchableOpacity>

        <TouchableOpacity style={estilo.button}>
          <Text style={estilo.texto}>Compartilhar</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>

    
  );
}

const estilo = StyleSheet.create({
  foto: {
    width: 200,
    height: 200,
    alignSelf: 'center',
    borderRadius: 10,
    marginTop: 10,
  },

  container: {
    alignItems: 'center',
    padding: 10,
  },

  botao: {
    flexDirection: 'row',
    gap: 10,
    marginTop:10,
  },
  
  button:{
    backgroundColor:'#3f6e55',
    borderRadius:10,
    padding:5,
    width:100,
    height:25,
    alignItems:'center'
  },

  texto:{
    color:'#fff'
  }


});

export default galeriaFotos;
